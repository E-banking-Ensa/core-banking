package org.example.core_bancaire_soap.entity;

public enum TypeTransaction {

    VIREMENT,
    RECHARGE,
    DEPOSIT,
    CRYPTO_SELL,
    CRYPTO_BUY
}
