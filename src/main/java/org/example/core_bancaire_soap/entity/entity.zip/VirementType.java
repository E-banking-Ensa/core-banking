package org.example.core_bancaire_soap.entity;

public enum VirementType {
    CLASSIC, Instantane

}
